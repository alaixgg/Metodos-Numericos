a=152
b=-56
c=-82
x=c-b
z=x/a
fprintf('x es igual a: %2.2f\n ',z)
