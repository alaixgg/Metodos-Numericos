r=input('Escriba el radio del clindro: ');
h=input('Escriba la altura del clindro: ');

v=(pi*r^2)*h
fprintf('El Volumen del cilindro es: %12.4f\n',v)
