a=1
b=5
c=-24
x1=(-b+sqrt(b^2-4*a*c))/(2*a)
x2=(-b-sqrt(b^2-4*a*c))/(2*a)
fprintf('x1 es igual a: %2.2f\n ',x1)
fprintf('x2 es igual a: %2.2f\n ',x2)
