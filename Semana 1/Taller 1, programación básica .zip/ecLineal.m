a=input('Ecuacion Lineal, ingrese el valor de a: ' );
b=input('Ingrese ahora el valor de b: ');
c=input('ingrese el valor de de c: ');
x=c-b
z=x/a
fprintf('x es igual a: %2.2f\n ',z)
