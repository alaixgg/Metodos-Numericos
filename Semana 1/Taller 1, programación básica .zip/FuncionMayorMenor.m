function [m]=menor(a,b)
  if a<b
    m=a
  else
    m=b
   endif
end
