b= input('ingrese la base del triangulo: ');
a= input('Ingrese la altura del trianugulo: ');

area=(b*a)/2;
display(area)
