%Ejemplo calculo del area del un circulo
r=input('Ingrese el valor del radio: ');
A=pi*r^2;
fprintf('El area es: %12.4f\n',A)
