a=input('Ecuacion Cuadratica, ingrese el valor de a: ' );
b=input('Ingrese ahora el valor de b: ');
c=input('ingrese el valor de de c: ');
x1=(-b+sqrt(b^2-4*a*c))/(2*a)
x2=(-b-sqrt(b^2-4*a*c))/(2*a)
fprintf('x1 es igual a: %2.2f\n ',x1)
fprintf('x1 es igual a: %2.2f\n ',x2)
