function A=area(r)
  A=pi*r^2
  endfunction
